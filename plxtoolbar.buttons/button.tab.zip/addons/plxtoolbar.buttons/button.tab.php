<?php
/**
 * button.tab
  *
 * @package PLX 5.+
 * @author	St�phane F
 * @version 1.0
 **/
?>
<?php if(!defined('PLX_ROOT')) exit; ?>

<script type="text/javascript">
<!--
plxToolbar.addButton( {
		icon : '<?php echo PLX_ROOT ?>addons/plxtoolbar.buttons/tab.png',
		title : 'Ins&eacute;rer tabulation',
		onclick : function() {
			return '\t';
		}
});
-->
</script>
