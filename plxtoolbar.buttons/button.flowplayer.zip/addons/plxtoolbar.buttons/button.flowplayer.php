<script type="text/javascript">
<!--
plxToolbar.addButton( {
	icon : '<?php echo PLX_ROOT ?>addons/plxtoolbar.buttons/film_add.png',
	title : 'Lecteur de video',
	onclick : function(textarea) {
		var flvurl = prompt('Adress du fichier', 'data/documents/');
		if (flvurl!='') {
			id_player = Math.ceil(Math.random() * 10000);
			s  = '<a href="'+flvurl+'" style="display:block;width:520px;height:330px" id="player'+id_player+'"><\/a>\n';
			s += '<script type="text/javascript">\n';
			s += 'flowplayer("player'+id_player+'", "<?php echo PLX_ROOT ?>addons/player.flowplayer/flowplayer-3.2.5.swf", {clip:{autoPlay:false,autoBuffering: true}});\n';
			s += '<\/script>\n';		
			return s;
		}
		return '';
	}
});
-->
</script>