<?php
/**
 * button.color
 *
 * @package PLX 5.+
 * @author	St�phane F
 * @version 1.0
 **/
?>
<?php if(!defined('PLX_ROOT')) exit; ?>

<script type="text/javascript">
<!--
plxToolbar.addButton( {
		icon : '<?php echo PLX_ROOT ?>addons/plxtoolbar.buttons/color.png',
		title : 'Couleur',
		onclick : function(textarea) {
			var color = prompt('Code couleur', '');
			if(color!=null) {
				plxToolbar.insert(textarea, '<span style="color:'+color+'">', '<\/span>', '', '');
			}
			return '';
		}
});
-->
</script>
