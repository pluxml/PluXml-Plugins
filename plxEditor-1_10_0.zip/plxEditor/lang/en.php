<?php
$LANG = array(
	'L_STATIC'	=> 'Activate plxEditor with static page edit',
	'L_SAVE'	=> 'Enregister',
);

