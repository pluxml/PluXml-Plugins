<?php
$LANG = array(
	'L_STATIC'	=> 'Utiliser plxEditor pour l\'édition du contenu des pages statiques',
	'L_SAVE'	=> 'Enregistrer',
);

