<?php
$LANG = array(
	'L_STATIC'	=> 'Utilizar plxEditor per l\'edicion del contengut de las paginas estaticas',
	'L_SAVE'	=> 'Enregistrar',
);

