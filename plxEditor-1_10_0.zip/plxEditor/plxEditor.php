<?php
/**
 * Plugin plxEditor
 *
 * @package	PLX
 * @author	Stephane F, fork by Pedro "P3ter" CADETE, Jean-Pierre Pourrez @bazooka07
 **/
class plxEditor extends plxPlugin {
	const BEGIN_CODE = '<?php # ' . __CLASS__ . ' plugin' . PHP_EOL;
	const END_CODE = PHP_EOL . '?>';
	const ROOT = PLX_PLUGINS . __CLASS__ . '/';
	const HOOKS = array(
		'AdminTopEndHead',
		'AdminFootEndBody',

		'AdminArticlePrepend',
		'AdminArticleTop', # and AdminStaticTop
		'AdminArticlePreview',

		'AdminStaticTop',

		'plxAdminEditArticle', # and plxAdminEditStatique
	);

	public $racine = null;
	public $medias = null;

	/**
	 * Constructeur de la classe
	 *
	 * @param	default_lang	langue par défaut utilisée par PluXml
	 * @return	null
	 * @author	Stephane F
	 **/
	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		$this->default_lang = $default_lang;

		# droits pour accèder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		# déclaration pour ajouter l'éditeur de pages statiques
		$hasStatic = ($this->getParam('static') == 1);
		$static =  $hasStatic ? '' : '|statique';

		# Déclarations des hooks
		if(defined('PLX_ADMIN') and !preg_match('#^(?:parametres_edittpl|comment' . $static . ')$#', basename($_SERVER['SCRIPT_NAME'], '.php'))) {
			foreach(self::HOOKS as $hook) {
				$this->addHook($hook,$hook);
			}
			if($hasStatic) {
				$this->addHook('AdminStaticTop', 'AdminArticleTop');
				$this->addHook('plxAdminEditStatic', 'plxAdminEditArticle');
			}
		}

	}

	/**
	 * Méthode qui convertit les liens relatifs en liens absolus
	 *
	 * @return	stdio
	 * @author	Stephane F
	 **/
	public function plxAdminEditArticle() {
		echo self::BEGIN_CODE;
?>
$replaces = array(
	PLX_ROOT . $this->aConf['medias'] => $this->aConf['medias'],
	PLX_ROOT . $this->aConf['racine_plugins'] => $this->aConf['racine_plugins'],
	plxUtils::getRacine() => '',
);
foreach(array('chapo', 'content') as $f) {
	if(array_key_exists($f, $content) and !empty(trim($content[$f]))) {
		$content[$f] = strtr(trim($content[$f]), $replaces);
	}
}
<?php
		echo self::END_CODE;
	}

	/**
	 * Méthode qui convertit les liens relatifs en liens absolus
	 *
	 * @return	stdio
	 * @author	Stephane F
	 **/
	public function AdminArticlePreview() {
		# Like self::plxAdminEditArticle() but with $art instead $content
		echo self::BEGIN_CODE;
?>
$replaces = array(
	PLX_ROOT . $plxAdmin->aConf['medias'] => $plxAdmin->aConf['medias'],
	PLX_ROOT . $plxAdmin->aConf['racine_plugins'] => $plxAdmin->aConf['racine_plugins'],
	plxUtils::getRacine() => '',
);
foreach(array('chapo', 'content') as $f) {
	if(!empty(trim($art[$f]))) {
		$art[$f] = strtr(trim($art[$f]), $replaces);
	}
}
<?php
		echo self::END_CODE;
	}

	/**
	 * Méthode qui convertit les liens absolus en liens relatifs dans les articles et les pages statiques
	 *
	 * @return	stdio
	 * @author	Stephane F
	 **/
	public function AdminArticleTop() {
		echo self::BEGIN_CODE;
?>
$replaces = array(
	$plxAdmin->aConf['medias'] => PLX_ROOT . $plxAdmin->aConf['medias'],
	$plxAdmin->aConf['racine_plugins'] => PLX_ROOT . $plxAdmin->aConf['racine_plugins'],
);
if(!empty($chapo)) {
	$chapo = strtr($chapo, $replaces);
}
if(!empty($content)) {
	$content = strtr($content, $replaces);
}
<?php
		echo self::END_CODE;
	}

	/**
	 * Méthode du hook AdminTopEndHead
	 *
	 * @return	stdio
	 * @author	Stephane F
	 **/
	public function AdminTopEndHead() {
?>
		<link rel="stylesheet" type="text/css" href="<?= self::ROOT ?>plxEditor/css/plxEditor.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="<?= self::ROOT ?>plxEditor/css/viewsource.css" media="screen" />
<?php
		echo self::BEGIN_CODE;
?>
$plugin = $plxAdmin->plxPlugins->aPlugins['<?= __CLASS__ ?>'];
$plugin->racine = $plxAdmin->racine;
$plugin->medias = $plxAdmin->aConf['medias'] . ($plxAdmin->aConf['userfolders'] ? $_SESSION['user'] . '/' : '');
<?php
		echo self::END_CODE;
	}

	/**
	 * Méthode du hook AdminFootEndBody
	 *
	 * @return	stdio
	 * @author	Stephane F
	 **/
	public function AdminFootEndBody() {
		$lang = $this->default_lang;
		if(!is_file(__DIR__ . '/plxEditor/lang/' . $lang . '.js')) {
			$lang = DEFAULT_LANG;
		}
?>
	<script src="<?= self::ROOT ?>plxEditor/lang/<?= $lang ?>.js"></script>
	<script
		id="plxEditorJS"
		src="<?= self::ROOT ?>plxEditor/plxEditor.js"
		data-plx_plugins="<?= PLX_PLUGINS ?>"
		data-plx_racine="<?= $this->racine ?>"
		data-plx_medias="<?= $this->medias ?>"
	></script>
<?php
	}

}
