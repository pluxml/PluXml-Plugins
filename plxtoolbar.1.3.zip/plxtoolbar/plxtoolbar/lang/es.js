<!--
/**
 * @package 	PLX
 * @version 	1.0
 * @date		30/01/2011
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'P&aacute;rrafo',
'L_TOOLBAR_TITLE'					: 'T&iacute;tulo',
'L_TOOLBAR_BOLD'					: 'Texto en negrita',
'L_TOOLBAR_ITALIC'					: 'Texto en cursiva',
'L_TOOLBAR_UNDERLINE'				: 'Texto subrayado',
'L_TOOLBAR_STRIKE'					: 'Texto tachado ',
'L_TOOLBAR_LINK_MSG'				: 'Escriba una direcci&oacute;n',
'L_TOOLBAR_LINK'					: 'Enlace',
'L_TOOLBAR_BR'						: 'Salto de l&iacute;nea',
'L_TOOLBAR_HR'						: 'L&iacute;nea horizontal',
'L_TOOLBAR_UL'						: 'Vi&ntilde;eta',
'L_TOOLBAR_OL'						: 'Lista numerada',
'L_TOOLBAR_BLOCKQUOTE'				: 'Sangr&iacute;a',
'L_TOOLBAR_P_LEFT'					: 'Alineaci&oacute;n izquierda',
'L_TOOLBAR_P_RIGHT'					: 'Alineaci&oacute;n derecha',
'L_TOOLBAR_P_CENTER'				: 'Texto centrado',
'L_TOOLBAR_MEDIAS'					: 'Medios',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Gestor de medios',
'L_TOOLBAR_FULLSCREEN'				: 'Pantalla completa'
};
-->