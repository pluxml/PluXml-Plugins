<!--
/**
 * @package PLX
 * @version 1.0
 * @date	19/01/2011
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Paragraph',
'L_TOOLBAR_TITLE'					: 'Title',
'L_TOOLBAR_BOLD'					: 'Bold',
'L_TOOLBAR_ITALIC'					: 'Itaclic',
'L_TOOLBAR_UNDERLINE'				: 'Underlined',
'L_TOOLBAR_STRIKE'					: 'Strikethrough',
'L_TOOLBAR_LINK_MSG'				: 'Please enter url',
'L_TOOLBAR_LINK'					: 'Link',
'L_TOOLBAR_BR'						: 'Single line break',
'L_TOOLBAR_HR'						: 'Horizontal line',
'L_TOOLBAR_UL'						: 'Bulleted list',
'L_TOOLBAR_OL'						: 'Numbered list',
'L_TOOLBAR_BLOCKQUOTE'				: 'Blockquote',
'L_TOOLBAR_P_LEFT'					: 'Text to the left',
'L_TOOLBAR_P_RIGHT'					: 'Text to the right',
'L_TOOLBAR_P_CENTER'				: 'Text to center',
'L_TOOLBAR_MEDIAS'					: 'Medias',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Medias manager',
'L_TOOLBAR_FULLSCREEN'				: 'Fullscreen'
};
-->