<!--
/**
 * @package PLX
 * @version 1.0
 * @date	02/02/2011
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Absatz',
'L_TOOLBAR_TITLE'					: 'Titel',
'L_TOOLBAR_BOLD'					: 'Fettschrift',
'L_TOOLBAR_ITALIC'					: 'kursiv',
'L_TOOLBAR_UNDERLINE'				: 'unterstrichen;',
'L_TOOLBAR_STRIKE'					: 'durchgestrichen',
'L_TOOLBAR_LINK_MSG'				: 'Geben Sie Schrift',
'L_TOOLBAR_LINK'					: 'Verbindung',
'L_TOOLBAR_BR'						: 'Wickeln',
'L_TOOLBAR_HR'						: 'Horizontal Linie',
'L_TOOLBAR_UL'						: 'Aufz&auml;hlung',
'L_TOOLBAR_OL'						: 'Numerierte Liste',
'L_TOOLBAR_BLOCKQUOTE'				: 'R&uuml;ckzug',
'L_TOOLBAR_P_LEFT'					: 'Links',
'L_TOOLBAR_P_RIGHT'					: 'Rechts',
'L_TOOLBAR_P_CENTER'				: 'Mitte',
'L_TOOLBAR_MEDIAS'					: 'Daten',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Datenmanagement',
'L_TOOLBAR_FULLSCREEN'				: 'Vollbild'
};
-->