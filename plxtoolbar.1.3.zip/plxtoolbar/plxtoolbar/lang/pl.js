<!--
/**
 * @package PLX
 * @version 1.0
 * @date	19/01/2011
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Paragraf',
'L_TOOLBAR_TITLE'					: 'Tytuł',
'L_TOOLBAR_BOLD'					: 'Pogrubienie',
'L_TOOLBAR_ITALIC'					: 'Kursywa',
'L_TOOLBAR_UNDERLINE'				: 'Podkreślenie',
'L_TOOLBAR_STRIKE'					: 'Przekreślenie',
'L_TOOLBAR_LINK_MSG'				: 'Proszę podać adres url',
'L_TOOLBAR_LINK'					: 'Link',
'L_TOOLBAR_BR'						: 'Następna linijka',
'L_TOOLBAR_HR'						: 'Pozioma linia',
'L_TOOLBAR_UL'						: 'Punktor',
'L_TOOLBAR_OL'						: 'Numerowanie',
'L_TOOLBAR_BLOCKQUOTE'				: 'Blok z cytatem',
'L_TOOLBAR_P_LEFT'					: 'Tekst od lewej',
'L_TOOLBAR_P_RIGHT'					: 'Tekst od prawej',
'L_TOOLBAR_P_CENTER'				: 'Wyśrodkowanie',
'L_TOOLBAR_MEDIAS'					: 'Media',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Menadżer medii',
'L_TOOLBAR_FULLSCREEN'				: 'Pełny ekran'
};
-->