<!--
/**
 * @package PLX
 * @version 1.0
 * @date	04/12/2010
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Paragraphe',
'L_TOOLBAR_TITLE'					: 'Titre',
'L_TOOLBAR_BOLD'					: 'Text en Gras',
'L_TOOLBAR_ITALIC'					: 'Text en Italique',
'L_TOOLBAR_UNDERLINE'				: 'Texte soulign&eacute;',
'L_TOOLBAR_STRIKE'					: 'Texte barr&eacute;',
'L_TOOLBAR_LINK_MSG'				: 'Veuillez entrer une adresse',
'L_TOOLBAR_LINK'					: 'Lien',
'L_TOOLBAR_BR'						: 'Retour &agrave; la ligne',
'L_TOOLBAR_HR'						: 'Ligne horizontale',
'L_TOOLBAR_UL'						: 'Liste &agrave; puce',
'L_TOOLBAR_OL'						: 'Liste num&eacute;rot&eacute;e',
'L_TOOLBAR_BLOCKQUOTE'				: 'Retrait',
'L_TOOLBAR_P_LEFT'					: 'Texte &agrave; gauche',
'L_TOOLBAR_P_RIGHT'					: 'Texte &agrave; droite',
'L_TOOLBAR_P_CENTER'				: 'Texte centr&eacute;',
'L_TOOLBAR_MEDIAS'					: 'M&eacute;dias',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Gestionnaire de m&eacute;dias',
'L_TOOLBAR_FULLSCREEN'				: 'Plein &eacute;cran'
};
-->