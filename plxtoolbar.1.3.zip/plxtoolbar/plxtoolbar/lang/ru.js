<!--
/**
 * @package PLX
 * @version 1.0
 * @date	19/01/2011
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Параграф',
'L_TOOLBAR_TITLE'					: 'Название',
'L_TOOLBAR_BOLD'					: 'Жирный',
'L_TOOLBAR_ITALIC'					: 'Курсив',
'L_TOOLBAR_UNDERLINE'				: 'Подчеркнутый',
'L_TOOLBAR_STRIKE'					: 'Зачеркнутый',
'L_TOOLBAR_LINK_MSG'				: 'Пожалуйста, введите URL',
'L_TOOLBAR_LINK'					: 'Ссылка',
'L_TOOLBAR_BR'						: 'Разрыв строки',
'L_TOOLBAR_HR'						: 'Горизонтальная линия',
'L_TOOLBAR_UL'						: 'Маркированный список',
'L_TOOLBAR_OL'						: 'Нумерованный список',
'L_TOOLBAR_BLOCKQUOTE'				: 'Цитата',
'L_TOOLBAR_P_LEFT'					: 'Текст по левому краю',
'L_TOOLBAR_P_RIGHT'					: 'Текст по правому краю',
'L_TOOLBAR_P_CENTER'				: 'Текст по центру',
'L_TOOLBAR_MEDIAS'					: 'Медиа',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Загрузить медиа',
'L_TOOLBAR_FULLSCREEN'				: 'Во весь экран',
};
-->