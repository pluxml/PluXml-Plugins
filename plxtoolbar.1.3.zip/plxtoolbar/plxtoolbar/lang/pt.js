<!--
/**
 * @package PLX
 * @version 1.0
 * @date	04/12/2010
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Par&aacute;grafo',
'L_TOOLBAR_TITLE'					: 'Tit&uacute;lo',
'L_TOOLBAR_BOLD'					: 'Texto gordo',
'L_TOOLBAR_ITALIC'					: 'Texto it&aacute;lico',
'L_TOOLBAR_UNDERLINE'				: 'Texto sublinhado;',
'L_TOOLBAR_STRIKE'					: 'Texto barrado',
'L_TOOLBAR_LINK_MSG'				: 'D&iacute;gite un ender&ecir;&ccedil;o',
'L_TOOLBAR_LINK'					: 'Link',
'L_TOOLBAR_BR'						: 'Voltar &aacute; linha',
'L_TOOLBAR_HR'						: 'Linha horizontal',
'L_TOOLBAR_UL'						: 'Lista com marcadores',
'L_TOOLBAR_OL'						: 'Lista numerada',
'L_TOOLBAR_BLOCKQUOTE'				: 'Tabula&ccedil;&atilde;o',
'L_TOOLBAR_P_LEFT'					: 'Texto alinhado &aacute; esquerda',
'L_TOOLBAR_P_RIGHT'					: 'Texto alinhado &aacute; direita',
'L_TOOLBAR_P_CENTER'				: 'Texto ao centro;',
'L_TOOLBAR_MEDIAS'					: 'M&eacute;dias',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Gestion&aacute;rio de m&eacute;dias',
'L_TOOLBAR_FULLSCREEN'				: 'Agrandecer, tela completa'
};
-->