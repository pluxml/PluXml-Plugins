<!--
/**
 * @package PLX
 * @version 1.0
 * @date	18/01/2011
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Paragrafo',
'L_TOOLBAR_TITLE'					: 'Titolo',
'L_TOOLBAR_BOLD'					: 'Grassetto',
'L_TOOLBAR_ITALIC'					: 'Corsivo',
'L_TOOLBAR_UNDERLINE'				: 'Sottolineato',
'L_TOOLBAR_STRIKE'					: 'Barrato',
'L_TOOLBAR_LINK_MSG'				: 'Inserisci il collegamento',
'L_TOOLBAR_LINK'					: 'Collegamento',
'L_TOOLBAR_BR'						: 'A capo',
'L_TOOLBAR_HR'						: 'Linea orizzontale',
'L_TOOLBAR_UL'						: 'Elenco puntato',
'L_TOOLBAR_OL'						: 'Elenco numerato',
'L_TOOLBAR_BLOCKQUOTE'				: 'Rientro',
'L_TOOLBAR_P_LEFT'					: 'Allinea a sinistra',
'L_TOOLBAR_P_RIGHT'					: 'Allinea a destra',
'L_TOOLBAR_P_CENTER'				: 'Centra',
'L_TOOLBAR_MEDIAS'					: 'Media',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Gestore dei media',
'L_TOOLBAR_FULLSCREEN'				: 'A tutto schermo'
};
-->
