<!--
/**
 * @package PLX
 * @version 1.0
 * @date	04/12/2010
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Paragraph',
'L_TOOLBAR_TITLE'					: 'Title',
'L_TOOLBAR_BOLD'					: 'Bold',
'L_TOOLBAR_ITALIC'					: 'Italic',
'L_TOOLBAR_UNDERLINE'				: 'Underline',
'L_TOOLBAR_STRIKE'					: 'Strike',
'L_TOOLBAR_LINK_MSG'				: 'Link Msg',
'L_TOOLBAR_LINK'					: 'Link',
'L_TOOLBAR_BR'						: 'Wrap',
'L_TOOLBAR_HR'						: 'Linie orizontala',
'L_TOOLBAR_UL'						: 'Lista cu marcatori',
'L_TOOLBAR_OL'						: 'Lista numerotata',
'L_TOOLBAR_BLOCKQUOTE'				: 'Blackquote',
'L_TOOLBAR_P_LEFT'					: 'Text stanga',
'L_TOOLBAR_P_RIGHT'					: 'Text dreapta',
'L_TOOLBAR_P_CENTER'				: 'Text centru',
'L_TOOLBAR_MEDIAS'					: 'Media',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Media Manager',
'L_TOOLBAR_FULLSCREEN'				: 'Fullscreen'
};
-->