<!--
/**
 * @package PLX
 * @version 1.0
 * @date	04/12/2010
 **/
lang={
'L_TOOLBAR_PARAGRAPH'				: 'Paragraaf',
'L_TOOLBAR_TITLE'					: 'Titel',
'L_TOOLBAR_BOLD'					: 'Vetgedrukte tekst',
'L_TOOLBAR_ITALIC'					: 'Italische tekst',
'L_TOOLBAR_UNDERLINE'				: 'Onderstreepte tekst',
'L_TOOLBAR_STRIKE'					: 'Doorstreepte tekst',
'L_TOOLBAR_LINK_MSG'				: 'Geef een URL',
'L_TOOLBAR_LINK'					: 'Link',
'L_TOOLBAR_BR'						: 'Volgende regel',
'L_TOOLBAR_HR'						: 'Horizontale lijn',
'L_TOOLBAR_UL'						: 'Lijst met bullets',
'L_TOOLBAR_OL'						: 'Lijst met nummers',
'L_TOOLBAR_BLOCKQUOTE'				: 'Tekstblok',
'L_TOOLBAR_P_LEFT'					: 'Tekst links',
'L_TOOLBAR_P_RIGHT'					: 'Tekst rechts',
'L_TOOLBAR_P_CENTER'				: 'Tekst gecentreerd',
'L_TOOLBAR_MEDIAS'					: 'Media',
'L_TOOLBAR_MEDIAS_TITLE'			: 'Media-beheer',
'L_TOOLBAR_FULLSCREEN'				: 'Volledig scherm'
};
-->