<?php
/**
 * button.tab
  *
 * @package PLX 5.1
 * @author	St�phane F
 * @version 1.01
 **/
?>
<?php if(!defined('PLX_ROOT')) exit; ?>

<script type="text/javascript">
<!--
plxToolbar.addButton( {
		icon : '<?php echo PLX_PLUGINS ?>plxtoolbar/custom.buttons/tab.png',
		title : 'Ins&eacute;rer tabulation',
		onclick : function() {
			return '\t';
		}
});
-->
</script>
